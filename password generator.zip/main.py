import random
import string

def generate_password(length):
    # Combine letters, digits, and special characters for a stronger password
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

def main():
    print("Welcome to the Password Generator!")

    # Get user input for the desired length of the password
    while True:
        try:
            password_length = int(input("Enter the desired length of the password: "))
            if password_length <= 0:
                print("Please enter a positive integer.")
            else:
                break
        except ValueError:
            print("Invalid input. Please enter a valid integer.")

    # Generate and display the password
    password = generate_password(password_length)
    print(f"Generated Password: {password}")

if __name__ == "__main__":
    main()
